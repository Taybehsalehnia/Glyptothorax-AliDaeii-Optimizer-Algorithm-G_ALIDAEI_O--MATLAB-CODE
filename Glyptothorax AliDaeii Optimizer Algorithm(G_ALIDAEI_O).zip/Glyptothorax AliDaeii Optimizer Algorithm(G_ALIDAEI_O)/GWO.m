%==================================================================
% GWO - Grey Wolf Optimizer (Function for MAIN)
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = GWO(N, Max_iteration, LB, UB, Dim, F_obj)

disp('GWO is now tackling your problem');

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% Initialize alpha, beta, delta
Alpha_pos = zeros(1, Dim);
Alpha_score = inf;

Beta_pos = zeros(1, Dim);
Beta_score = inf;

Delta_pos = zeros(1, Dim);
Delta_score = inf;

% Initialize positions of search agents
Positions = initialization(N, Dim, UB, LB);

% History arrays
cg_curve = zeros(1, Max_iteration);
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);

% Main loop
for l = 1:Max_iteration
    a = 2 - l * (2 / Max_iteration); % linearly decreasing from 2 to 0
    
    for i = 1:N
        % Bound check
        Positions(i,:) = max(min(Positions(i,:), UB), LB);
        
        % Calculate fitness
        fitness = F_obj(Positions(i,:));
        
        % Update alpha, beta, delta
        if fitness < Alpha_score
            Alpha_score = fitness;
            Alpha_pos = Positions(i,:);
        elseif fitness < Beta_score && fitness > Alpha_score
            Beta_score = fitness;
            Beta_pos = Positions(i,:);
        elseif fitness < Delta_score && fitness > Beta_score && fitness > Alpha_score
            Delta_score = fitness;
            Delta_pos = Positions(i,:);
        end
    end
    
    % Update positions of search agents
    for i = 1:N
        for j = 1:Dim
            r1 = rand(); r2 = rand();
            A1 = 2*a*r1 - a; C1 = 2*r2;
            D_alpha = abs(C1*Alpha_pos(j) - Positions(i,j));
            X1 = Alpha_pos(j) - A1*D_alpha;

            r1 = rand(); r2 = rand();
            A2 = 2*a*r1 - a; C2 = 2*r2;
            D_beta = abs(C2*Beta_pos(j) - Positions(i,j));
            X2 = Beta_pos(j) - A2*D_beta;

            r1 = rand(); r2 = rand();
            A3 = 2*a*r1 - a; C3 = 2*r2;
            D_delta = abs(C3*Delta_pos(j) - Positions(i,j));
            X3 = Delta_pos(j) - A3*D_delta;

            Positions(i,j) = (X1 + X2 + X3) / 3;
        end
    end
    
    % Save history
    Trajectories(:, l) = repmat(Alpha_score, N, 1);
    fitness_history(:, l) = repmat(Alpha_score, N, 1);
    position_history(:,:,l) = Positions;
    cg_curve(l) = Alpha_score;
    
    fprintf('Iteration %d, Best fitness = %4.6f\n', l, Alpha_score);
end

Best_FF = Alpha_score;
Best_P = Alpha_pos;

end
