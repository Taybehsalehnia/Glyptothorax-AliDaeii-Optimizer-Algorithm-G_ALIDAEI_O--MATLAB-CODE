%===========================================
% G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm
% Programmer : Taybeh Salehnia
% Email      : salehnia.taybeh@gmail.com
%===========================================


function [TargetFitness, TargetPosition, Convergence_curve, Trajectories, fitness_history, position_history] = G_AliDaei_O(N, Max_iter, lb, ub, dim, fobj)

%===========================================
disp('======================================');
disp('Programmer : Taybeh Salehnia');
disp('Email      : salehnia.taybeh@gmail.com');
disp('======================================');
%===========================================
disp('G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm');
disp('G-AliDaei-O is now estimating the global optimum...');

if size(ub,1)==1
    ub = ones(dim,1)*ub;
    lb = ones(dim,1)*lb;
end

% Initialize population
X = initialization(N, dim, ub, lb);
Fitness = zeros(1,N);
adhesion = rand(N,1);        
Energy = ones(N,1);          

fitness_history = zeros(N,Max_iter);
position_history = zeros(N,Max_iter,dim);
Convergence_curve = zeros(1,Max_iter);
Trajectories = zeros(N,Max_iter);


for i=1:N
    Fitness(i) = fobj(X(i,:));
    fitness_history(i,1) = Fitness(i);
    position_history(i,1,:) = X(i,:);
    Trajectories(:,1) = X(:,1);
end

[sorted_fitness, sorted_idx] = sort(Fitness);
X_sorted = X(sorted_idx,:);
TargetPosition = X_sorted(1,:);
TargetFitness = sorted_fitness(1);


p_burst = linspace(0.3, 0.05, Max_iter);   
p_forage = 0.5;
p_stabilize = 0.2;


for iter=2:Max_iter
    for i=1:N
        r = rand;
        
        if r < p_stabilize
            behavior = 'Attachment';
        elseif r < p_stabilize + p_forage
            behavior = 'Forage';
        elseif r < p_stabilize + p_forage + p_burst(iter)
            behavior = 'Burst';
        else
            behavior = 'Cluster';
        end

        switch behavior
            case 'Attachment'
                sigma_local = 0.01;
                delta = randn(1,dim)*sigma_local;
                X(i,:) = X(i,:) + adhesion(i)*delta;

            case 'Forage'
                k = min(5,N); 
                neighbors_idx = randperm(N,k);
                m = mean(X(neighbors_idx,:),1);
                alpha = 0.5;
                X(i,:) = X(i,:) + alpha*(m - X(i,:)) + rand(1,dim)*0.01;

            case 'Burst'
                beta = 1.0; gamma = 0.1;
                X(i,:) = X(i,:) + beta*(TargetPosition - X(i,:)) + gamma*rand(1,dim).*(ub'-lb');

            case 'Cluster'
                %  K-means
                K = round(sqrt(N));
                [idx,C] = kmeans(X,K,'MaxIter',5,'Replicates',1);
                clust_id = idx(i);
                cluster_mean = C(clust_id,:);
                X(i,:) = X(i,:) + 0.2*(cluster_mean - X(i,:));
        end

        % 
        X(i,:) = max(min(X(i,:), ub'), lb');

        % fitness 
        newFitness = fobj(X(i,:));

        % 
        if newFitness < Fitness(i)
            Energy(i) = Energy(i) + 0.1;
        else
            Energy(i) = max(0, Energy(i) - 0.1);
        end

        Fitness(i) = newFitness;
        fitness_history(i,iter) = Fitness(i);
        position_history(i,iter,:) = X(i,:);
        Trajectories(:,iter) = X(:,1);

        
        if Fitness(i) < TargetFitness
            TargetFitness = Fitness(i);
            TargetPosition = X(i,:);
        end
    end

    Convergence_curve(iter) = TargetFitness;
    disp(['Iteration #', num2str(iter), ', Best fitness = ', num2str(TargetFitness)]);
end
end
