function cost=SphereFun(x,m)
cost=sum(x.^2);
end
