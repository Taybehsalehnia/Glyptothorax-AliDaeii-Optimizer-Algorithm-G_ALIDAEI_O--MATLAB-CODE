function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = SSA(N, Max_iter, LB, UB, Dim, F_obj)

disp('SSA is now tackling your problem');

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% Initialize positions of salps
SalpPositions = initialization(N, Dim, UB, LB);

% Initialize Food (best solution)
FoodPosition = zeros(1, Dim);
FoodFitness = inf;

% History arrays
cg_curve = zeros(1, Max_iter);
Trajectories = zeros(N, Max_iter);
fitness_history = zeros(N, Max_iter);
position_history = zeros(N, Dim, Max_iter);

% Evaluate initial fitness
SalpFitness = zeros(1, N);
for i = 1:N
    SalpFitness(i) = F_obj(SalpPositions(i,:));
    if SalpFitness(i) < FoodFitness
        FoodFitness = SalpFitness(i);
        FoodPosition = SalpPositions(i,:);
    end
end

% Main loop
for l = 1:Max_iter
    c1 = 2 * exp(-(4*l/Max_iter)^2); % control parameter
    
    for i = 1:N
        if i <= N/2
            for j = 1:Dim
                c2 = rand();
                c3 = rand();
                if c3 < 0.5
                    SalpPositions(i,j) = FoodPosition(j) + c1*((UB(j)-LB(j))*c2 + LB(j));
                else
                    SalpPositions(i,j) = FoodPosition(j) - c1*((UB(j)-LB(j))*c2 + LB(j));
                end
            end
        else
            SalpPositions(i,:) = (SalpPositions(i,:) + SalpPositions(i-1,:)) / 2;
        end
    end
    
    % Bound check and fitness evaluation
    for i = 1:N
        SalpPositions(i,:) = max(min(SalpPositions(i,:), UB), LB);
        SalpFitness(i) = F_obj(SalpPositions(i,:));
        if SalpFitness(i) < FoodFitness
            FoodFitness = SalpFitness(i);
            FoodPosition = SalpPositions(i,:);
        end
    end
    
    % Save history
    Trajectories(:,l) = SalpFitness';
    fitness_history(:,l) = SalpFitness';
    position_history(:,:,l) = SalpPositions;
    cg_curve(l) = FoodFitness;
    
    fprintf('Iteration %d, Best fitness = %4.6f\n', l, FoodFitness);
end

Best_FF = FoodFitness;
Best_P = FoodPosition;

end
