%==================================================================
% Moth-Flame Optimization Algorithm (MFO) - Function Version for MAIN
%==================================================================
function [Best_flame_score, Best_flame_pos, Convergence_curve, Trajectories, fitness_history, position_history] = MFO(N, Max_iteration, lb, ub, dim, fobj)

display('MFO is optimizing your problem');

% Initialize moth positions
Moth_pos = initialization(N, dim, ub, lb);

% History tracking
Convergence_curve = zeros(1, Max_iteration);
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, dim, Max_iteration);

Iteration = 1;

while Iteration <= Max_iteration
    
    % Number of flames
    Flame_no = round(N - Iteration*((N-1)/Max_iteration));
    
    % Evaluate moths and check bounds
    Moth_fitness = zeros(1,N);
    for i = 1:N
        Flag4ub = Moth_pos(i,:) > ub;
        Flag4lb = Moth_pos(i,:) < lb;
        Moth_pos(i,:) = Moth_pos(i,:).*(~(Flag4ub+Flag4lb)) + ub.*Flag4ub + lb.*Flag4lb;
        
        % Fitness
        Moth_fitness(i) = fobj(Moth_pos(i,:));
    end
    
    % Sort and update flames
    if Iteration == 1
        [fitness_sorted, I] = sort(Moth_fitness);
        sorted_population = Moth_pos(I,:);
        best_flames = sorted_population;
        best_flame_fitness = fitness_sorted;
    else
        double_population = [previous_population; best_flames];
        double_fitness = [previous_fitness, best_flame_fitness];
        [double_fitness_sorted, I] = sort(double_fitness);
        double_sorted_population = double_population(I,:);
        fitness_sorted = double_fitness_sorted(1:N);
        sorted_population = double_sorted_population(1:N,:);
        best_flames = sorted_population;
        best_flame_fitness = fitness_sorted;
    end
    
    % Update best flame so far
    Best_flame_score = fitness_sorted(1);
    Best_flame_pos = sorted_population(1,:);
    
    % Store history
    Trajectories(:,Iteration) = Moth_fitness';
    fitness_history(:,Iteration) = Moth_fitness';
    position_history(:,:,Iteration) = Moth_pos;
    Convergence_curve(Iteration) = Best_flame_score;
    
    previous_population = Moth_pos;
    previous_fitness = Moth_fitness;
    
    % a decreases linearly from -1 to -2
    a = -1 + Iteration*((-1)/Max_iteration);
    
    for i = 1:N
        for j = 1:dim
            b = 1;
            t = (a-1)*rand + 1;
            
            if i <= Flame_no
                distance_to_flame = abs(sorted_population(i,j) - Moth_pos(i,j));
                Moth_pos(i,j) = distance_to_flame*exp(b*t)*cos(t*2*pi) + sorted_population(i,j);
            else
                distance_to_flame = abs(sorted_population(i,j) - Moth_pos(i,j));
                Moth_pos(i,j) = distance_to_flame*exp(b*t)*cos(t*2*pi) + sorted_population(Flame_no,j);
            end
        end
    end
    
    if mod(Iteration,50) == 0
        display(['At iteration ', num2str(Iteration), ' the best fitness is ', num2str(Best_flame_score)]);
    end
    
    Iteration = Iteration + 1;
end

end
