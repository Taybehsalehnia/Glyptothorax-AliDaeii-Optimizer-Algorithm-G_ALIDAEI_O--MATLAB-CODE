%==================================================================
% HHO - Harris Hawks Optimization (Function version for MAIN)
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = HHO(N, Max_iteration, LB, UB, Dim, F_obj)

disp('HHO is now tackling your problem');

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% Initialize rabbit (best solution)
Best_P = zeros(1, Dim);
Best_FF = inf;

% Initialize population
X = initialization(N, Dim, UB, LB);

% History
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);
cg_curve = zeros(1, Max_iteration);

t = 1;

while t <= Max_iteration
    % Evaluate fitness and update rabbit
    for i = 1:N
        % Bound check
        F_UB = X(i,:) > UB;
        F_LB = X(i,:) < LB;
        X(i,:) = X(i,:).*(~(F_UB + F_LB)) + UB.*F_UB + LB.*F_LB;
        
        f = F_obj(X(i,:));
        if f < Best_FF
            Best_FF = f;
            Best_P = X(i,:);
        end
    end
    
    E1 = 2*(1 - t/Max_iteration); % rabbit energy factor
    
    % Update positions of hawks
    for i = 1:N
        E0 = 2*rand() - 1;
        Escaping_Energy = E1 * E0;
        r = rand();
        
        if abs(Escaping_Energy) >= 1
            %% Exploration
            q = rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index,:);
            if q < 0.5
                X(i,:) = X_rand - rand()*abs(X_rand - 2*rand()*X(i,:));
            else
                X(i,:) = Best_P - rand() * ((UB - LB).*rand(1, Dim) + LB);
            end
        else
            %% Exploitation
            Jump_strength = 2*(1 - rand());
            if r >= 0.5 && abs(Escaping_Energy) < 0.5
                % Hard besiege
                X(i,:) = Best_P - Escaping_Energy * abs(Best_P - X(i,:));
            elseif r >= 0.5 && abs(Escaping_Energy) >= 0.5
                % Soft besiege
                X(i,:) = (Best_P - X(i,:)) - Escaping_Energy * abs(Jump_strength*Best_P - X(i,:));
            elseif r < 0.5 && abs(Escaping_Energy) >= 0.5
                % Soft besiege with rapid dives
                X1 = Best_P - Escaping_Energy * abs(Jump_strength*Best_P - X(i,:));
                if F_obj(X1) < F_obj(X(i,:))
                    X(i,:) = X1;
                else
                    X2 = X1 + rand(1,Dim).*Levy(Dim);
                    if F_obj(X2) < F_obj(X(i,:))
                        X(i,:) = X2;
                    end
                end
            elseif r < 0.5 && abs(Escaping_Energy) < 0.5
                % Hard besiege with rapid dives
                X1 = Best_P - Escaping_Energy * abs(Jump_strength*Best_P - mean(X));
                if F_obj(X1) < F_obj(X(i,:))
                    X(i,:) = X1;
                else
                    X2 = X1 + rand(1,Dim).*Levy(Dim);
                    if F_obj(X2) < F_obj(X(i,:))
                        X(i,:) = X2;
                    end
                end
            end
        end
    end
    
    % Save history
    Trajectories(:,t) = arrayfun(@(k) F_obj(X(k,:)), 1:N)';
    for k = 1:N
        position_history(k,:,t) = X(k,:);
        fitness_history(k,t) = F_obj(X(k,:));
    end
    cg_curve(t) = Best_FF;
    
    t = t + 1;
end

end

%==================================================================
% Levy flight function
%==================================================================
function step = Levy(d)
beta = 1.5;
sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u = randn(1,d)*sigma;
v = randn(1,d);
step = u ./ abs(v).^(1/beta);
end
