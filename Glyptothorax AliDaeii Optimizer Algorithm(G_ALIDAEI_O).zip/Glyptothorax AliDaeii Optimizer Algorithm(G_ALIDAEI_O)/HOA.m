function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = HOA(N, Max_iter, LB, UB, Dim, F_obj)

% Initialization of velocities and positions
VelMax = 0.1 * (UB - LB);
VelMin = -VelMax;
w = 0.999; % damping factor

% Parameters for different horse types
Pn = 0.04; % best horses fraction
Qn = 0.04; % worst horses fraction

Alpha.g = 1.50; Alpha.d = 0.5; Alpha.h = 1.5;
Beta.g = 1.50;  Beta.d = 0.2; Beta.h = 0.9; Beta.s = 0.2;
Gamma.g = 1.50; Gamma.d = 0.10; Gamma.h = 0.50; Gamma.s = 0.10; Gamma.i = 0.30; Gamma.r = 0.05;
Delta.g = 1.50; Delta.r = 0.10;

% Initialize horse structure
horse.Position = zeros(1, Dim);
horse.Cost = inf;
horse.Velocity = zeros(1, Dim);

Horses = repmat(horse, N, 1);
for i = 1:N
    Horses(i).Position = unifrnd(LB, UB);
    Horses(i).Cost = F_obj(Horses(i).Position);
    Horses(i).Velocity = zeros(1, Dim);
end
PersonalBest = Horses;

% Find global best
[~, idx] = min([Horses.Cost]);
GlobalBest = Horses(idx);

% History arrays
cg_curve = zeros(1, Max_iter);
Trajectories = zeros(N, Max_iter);
fitness_history = zeros(N, Max_iter);
position_history = zeros(N, Dim, Max_iter);

% Main loop
for it = 1:Max_iter
    % Sort horses based on fitness
    [~, idx] = sort([Horses.Cost]);
    Horses = Horses(idx);
%     AllPositions = reshape([Horses.Position], Dim, N)';
    AllPositions = vertcat(Horses.Position);

    P = floor(Pn * N);
    Q = floor(Qn * N);
    GoodPosition = mean(AllPositions(1:P, :));
    BadPosition  = mean(AllPositions(N-Q+1:N, :));
    MeanPosition = mean(AllPositions);

    for i = 1:N
        if i <= 0.1*N % Alpha horses
            Horses(i).Velocity = Alpha.h*rand(1,Dim).*(GlobalBest.Position - Horses(i).Position) ...
                                - Alpha.d*rand(1,Dim).*(Horses(i).Position) ...
                                + Alpha.g*(0.95+0.1*rand)*(PersonalBest(i).Position - Horses(i).Position);
        elseif i <= 0.3*N % Beta horses
            Horses(i).Velocity = Beta.s*rand(1,Dim).*(MeanPosition - Horses(i).Position) ...
                                - Beta.d*rand(1,Dim).*(BadPosition - Horses(i).Position) ...
                                + Beta.h*rand(1,Dim).*(GlobalBest.Position - Horses(i).Position) ...
                                + Beta.g*(0.95+0.1*rand)*(PersonalBest(i).Position - Horses(i).Position);
        elseif i <= 0.6*N % Gamma horses
            Horses(i).Velocity = Gamma.s*rand(1,Dim).*(MeanPosition - Horses(i).Position) ...
                                + Gamma.r*rand(1,Dim).*(Horses(i).Position) ...
                                - Gamma.d*rand(1,Dim).*(BadPosition - Horses(i).Position) ...
                                + Gamma.h*rand(1,Dim).*(GlobalBest.Position - Horses(i).Position) ...
                                + Gamma.i*rand(1,Dim).*(GoodPosition - Horses(i).Position) ...
                                + Gamma.g*(0.95+0.1*rand)*(PersonalBest(i).Position - Horses(i).Position);
        else % Delta horses
            Horses(i).Velocity = Delta.r*rand(1,Dim).*(Horses(i).Position) ...
                                + Delta.g*(0.95+0.1*rand)*(PersonalBest(i).Position - Horses(i).Position);
        end

        % Bound velocity
        Horses(i).Velocity = max(min(Horses(i).Velocity, VelMax), VelMin);

        % Update position
        Horses(i).Position = Horses(i).Position + Horses(i).Velocity;
        Horses(i).Position = max(min(Horses(i).Position, UB), LB);

        % Evaluate fitness
        Horses(i).Cost = F_obj(Horses(i).Position);

        % Update personal best
        if Horses(i).Cost < PersonalBest(i).Cost
            PersonalBest(i) = Horses(i);
            % Update global best
            if Horses(i).Cost < GlobalBest.Cost
                GlobalBest = Horses(i);
            end
        end
    end

    % Record history
    cg_curve(it) = GlobalBest.Cost;
    Trajectories(:, it) = [Horses.Cost]';
    fitness_history(:, it) = [Horses.Cost]';
    position_history(:,:,it) = reshape([Horses.Position], Dim, N)';

    % Dampen parameters
    Alpha.d = Alpha.d * w; Alpha.g = Alpha.g * w;
    Beta.d = Beta.d * w; Beta.s = Beta.s * w; Beta.g = Beta.g * w;
    Gamma.d = Gamma.d * w; Gamma.s = Gamma.s * w; Gamma.r = Gamma.r * w; Gamma.i = Gamma.i * w; Gamma.g = Gamma.g * w;
    Delta.r = Delta.r * w; Delta.g = Delta.g * w;

    fprintf('Iteration %d, Best Cost = %4.6f\n', it, GlobalBest.Cost);
end

% Output
Best_FF = GlobalBest.Cost;
Best_P = GlobalBest.Position;

end
