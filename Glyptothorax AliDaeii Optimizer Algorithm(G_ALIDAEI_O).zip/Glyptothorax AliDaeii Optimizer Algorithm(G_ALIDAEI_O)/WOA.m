%==================================================================
% Whale Optimization Algorithm (WOA) - Function Version for MAIN
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = WOA(N, Max_iteration, LB, UB, Dim, F_obj)

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% Initialize best solution
Best_P = zeros(1, Dim);
Best_FF = inf;

% Structure for whales
solution.Position = [];
solution.Cost = 0;
Wale = repmat(solution, [N,1]);

% Initialize population
for i = 1:N
    Wale(i).Position = unifrnd(LB, UB);  % Random within bounds
    Wale(i).Cost = F_obj(Wale(i).Position);
    
    % Update best
    if Wale(i).Cost < Best_FF
        Best_FF = Wale(i).Cost;
        Best_P = Wale(i).Position;
    end
end

% History tracking
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);
cg_curve = zeros(1, Max_iteration);

% Main loop
for it = 1:Max_iteration
    a = 2 - it*(2/Max_iteration);      % linearly decreases from 2 to 0
    a2 = -1 + it*((-1)/Max_iteration); % for spiral update
    
    for i = 1:N
        r1 = rand();
        r2 = rand();
        A = 2*a*r1 - a;
        C = 2*r2;
        b = 1;
        l = (a2 - 1)*rand + 1;
        p = rand();
        
        for j = 1:Dim
            if p < 0.5
                if abs(A) >= 1
                    rand_leader_index = floor(N*rand() + 1);
                    X_rand = Wale(rand_leader_index).Position;
                    D_X_rand = abs(C*X_rand(j) - Wale(i).Position(j));
                    Wale(i).Position(j) = X_rand(j) - A*D_X_rand;
                else
                    D_Leader = abs(C*Best_P(j) - Wale(i).Position(j));
                    Wale(i).Position(j) = Best_P(j) - A*D_Leader;
                end
            else
                distance2Leader = abs(Best_P(j) - Wale(i).Position(j));
                Wale(i).Position(j) = distance2Leader * exp(b*l) * cos(l*2*pi) + Best_P(j);
            end
        end
        
        % Check bounds
        Wale(i).Position = max(Wale(i).Position, LB);
        Wale(i).Position = min(Wale(i).Position, UB);
        
        % Evaluate fitness
        Wale(i).Cost = F_obj(Wale(i).Position);
        
        % Update best
        if Wale(i).Cost < Best_FF
            Best_FF = Wale(i).Cost;
            Best_P = Wale(i).Position;
        end
    end
    
    % Save history
    Trajectories(:, it) = [Wale.Cost]';
    fitness_history(:, it) = [Wale.Cost]';
    for k = 1:N
        position_history(k,:,it) = Wale(k).Position;
    end
    cg_curve(it) = Best_FF;
end

end
