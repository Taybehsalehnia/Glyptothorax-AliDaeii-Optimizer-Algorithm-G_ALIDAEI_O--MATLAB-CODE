%==================================================================
% PSO - Particle Swarm Optimization (Function for MAIN)
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = PSO(N, Max_iteration, LB, UB, Dim, F_obj)

disp('PSO is now tackling your problem');

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% PSO Parameters
Vmax = 6;
wMax = 0.9;
wMin = 0.2;
c1 = 2;
c2 = 2;

% Initialize positions and velocities
pos = initialization(N, Dim, UB, LB);
vel = zeros(N, Dim);

pBest = pos;
pBestScore = inf(1, N);

gBest = zeros(1, Dim);
Best_FF = inf;

% History arrays
cg_curve = zeros(1, Max_iteration);
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);

for iter = 1:Max_iteration
    % Evaluate fitness
    for i = 1:N
        % Bound check
        pos(i,:) = max(min(pos(i,:), UB), LB);
        fitness = F_obj(pos(i,:));
        
        if fitness < pBestScore(i)
            pBestScore(i) = fitness;
            pBest(i,:) = pos(i,:);
        end
        if fitness < Best_FF
            Best_FF = fitness;
            gBest = pos(i,:);
        end
    end
    
    % Update inertia weight
    w = wMax - iter * ((wMax - wMin)/Max_iteration);
    
    % Update velocities and positions
    for i = 1:N
        vel(i,:) = w*vel(i,:) + c1*rand(1,Dim).*(pBest(i,:) - pos(i,:)) + c2*rand(1,Dim).*(gBest - pos(i,:));
        
        % Velocity clamping
        vel(i,:) = max(min(vel(i,:), Vmax), -Vmax);
        
        % Update position
        pos(i,:) = pos(i,:) + vel(i,:);
        
        % Bound check again
        pos(i,:) = max(min(pos(i,:), UB), LB);
    end
    
    % Save history
    Trajectories(:, iter) = pBestScore';
    fitness_history(:, iter) = pBestScore';
    position_history(:,:,iter) = pos;
    cg_curve(iter) = Best_FF;
    
    fprintf('Iteration %d, Best fitness = %4.6f\n', iter, Best_FF);
end

Best_P = gBest;

end
