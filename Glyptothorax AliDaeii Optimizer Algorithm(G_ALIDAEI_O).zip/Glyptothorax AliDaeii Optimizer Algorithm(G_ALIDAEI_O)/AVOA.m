%==================================================================
% AVOA - African Vulture Optimization Algorithm (Function for MAIN)
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = AVOA(N, Max_iteration, LB, UB, Dim, F_obj)

disp('AVOA is now tackling your problem');

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% Initialize best vultures
Best_P = zeros(1, Dim);
Best_FF = inf;
Second_P = zeros(1, Dim);
Second_FF = inf;

% Initialize population
X = initialization(N, Dim, UB, LB);

% History arrays
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);
cg_curve = zeros(1, Max_iteration);

% Control parameters
p1 = 0.6; p2 = 0.4; p3 = 0.6;
alpha = 0.8; beta = 0.2; gamma = 2.5;

% Main loop
for t = 1:Max_iteration
    % Evaluate fitness and update best vultures
    for i = 1:N
        f = F_obj(X(i,:));
        if f < Best_FF
            Second_FF = Best_FF;  Second_P = Best_P; % Update second best
            Best_FF = f;
            Best_P = X(i,:);
        elseif f < Second_FF && f > Best_FF
            Second_FF = f;
            Second_P = X(i,:);
        end
    end
    
    % Update control factor
    a = unifrnd(-2,2) * ((sin((pi/2)*(t/Max_iteration))^gamma) + cos((pi/2)*(t/Max_iteration)) - 1);
    P1 = (2*rand+1)*(1-(t/Max_iteration)) + a;
    
    % Update positions
    for i = 1:N
        F = P1*(2*rand()-1);
        random_vulture_X = RandomSelect(Best_P, Second_P, alpha, beta, Dim);
        
        if abs(F) >= 1
            % Exploration
            X(i,:) = Exploration(X(i,:), random_vulture_X, F, p1, LB, UB);
        else
            % Exploitation
            X(i,:) = Exploitation(X(i,:), Best_P, Second_P, random_vulture_X, F, p2, p3, Dim, LB, UB);
        end
    end
    
    % Bound check
    X = min(max(X, LB), UB);
    
    % Save history
    Trajectories(:,t) = arrayfun(@(k) F_obj(X(k,:)), 1:N)';
    for k = 1:N
        position_history(k,:,t) = X(k,:);
        fitness_history(k,t) = F_obj(X(k,:));
    end
    cg_curve(t) = Best_FF;
    
    fprintf("Iteration %d, Best fitness = %4.6f\n", t, Best_FF);
end

end

%==================================================================
% Auxiliary functions
%==================================================================
function Xnew = RandomSelect(Best, Second, alpha, beta, Dim)
    idx = rand();
    if idx < 0.5
        Xnew = Best + alpha*rand(1,Dim);
    else
        Xnew = Second + beta*rand(1,Dim);
    end
end

function Xnew = Exploration(Xcurrent, Xrand, F, p1, LB, UB)
    Xnew = Xcurrent + F*(Xrand - Xcurrent)*p1;
    Xnew = min(max(Xnew, LB), UB);
end

function Xnew = Exploitation(Xcurrent, Best, Second, Xrand, F, p2, p3, Dim, LB, UB)
    Xnew = Xcurrent + F*(Best - Second)*p2 + p3*(Xrand - Xcurrent);
    Xnew = min(max(Xnew, LB), UB);
end
