%==================================================================
% Firefly Algorithm (FA) - Function Version for MAIN
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = Firefly(N, Max_iteration, LB, UB, Dim, F_obj)

% Convert scalar LB/UB to vector if needed
if isscalar(LB)
    LB = LB * ones(1, Dim);
end
if isscalar(UB)
    UB = UB * ones(1, Dim);
end

% FA Parameters
gamma = 1;      % Light absorption coefficient
beta0 = 2;      % Attraction coefficient
alpha = 0.2;    % Mutation coefficient
alpha_damp = 0.99;
delta = 0.05 * (UB - LB);  % Uniform mutation range
m = 2;

% Initialize Fireflies
firefly.Position = [];
firefly.Cost = [];
pop = repmat(firefly, N, 1);

BestSol.Position = zeros(1, Dim);
BestSol.Cost = inf;

for i = 1:N
    pop(i).Position = unifrnd(LB, UB);
    pop(i).Cost = F_obj(pop(i).Position);
    
    if pop(i).Cost <= BestSol.Cost
        BestSol = pop(i);
    end
end

% History
Trajectories = zeros(N, Max_iteration);
fitness_history = zeros(N, Max_iteration);
position_history = zeros(N, Dim, Max_iteration);
cg_curve = zeros(1, Max_iteration);

% Main loop
for it = 1:Max_iteration
    newpop = pop;
    
    for i = 1:N
        for j = 1:N
            if pop(j).Cost <= pop(i).Cost
                rij = norm(pop(i).Position - pop(j).Position);
                beta = beta0 * exp(-gamma * rij^m);
                e = delta .* unifrnd(-1, +1, [1, Dim]);
                
                newpop(i).Position = pop(i).Position ...
                    + beta * (pop(j).Position - pop(i).Position) ...
                    + alpha * e;
                
                % Bound check
                newpop(i).Position = max(newpop(i).Position, LB);
                newpop(i).Position = min(newpop(i).Position, UB);
                
                newpop(i).Cost = F_obj(newpop(i).Position);
                
                if newpop(i).Cost <= BestSol.Cost
                    BestSol = newpop(i);
                end
            end
        end
    end
    
    % Merge, sort, truncate
    pop = [pop; newpop; BestSol];
    [~, SortOrder] = sort([pop.Cost]);
    pop = pop(SortOrder);
    pop = pop(1:N);
    
    % Save history
    for k = 1:N
        position_history(k,:,it) = pop(k).Position;
        fitness_history(k,it) = pop(k).Cost;
    end
    Trajectories(:,it) = [pop.Cost]';
    cg_curve(it) = BestSol.Cost;
    
    % Update best cost
    Best_FF = BestSol.Cost;
    Best_P = BestSol.Position;
    
    % Damp mutation
    alpha = alpha * alpha_damp;
end

end
