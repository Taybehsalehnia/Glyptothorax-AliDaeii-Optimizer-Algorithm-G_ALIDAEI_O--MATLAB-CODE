%==================================================================
% Arithmetic Optimization Algorithm (AOA) - Function Version for MAIN
%==================================================================
function [Best_FF, Best_P, Conv_curve, Trajectories, fitness_history, position_history] = AOA(N, M_Iter, LB, UB, Dim, F_obj)

display('AOA Working');

% Initialize best solution
Best_P = zeros(1, Dim);
Best_FF = inf;

% Initialize convergence curve and history
Conv_curve = zeros(1, M_Iter);
Trajectories = zeros(N, M_Iter);
fitness_history = zeros(N, M_Iter);
position_history = zeros(N, Dim, M_Iter);

% Initialize population
X = initialization(N, Dim, UB, LB);
Xnew = X;

Ffun = zeros(1, N);       % fitness values
Ffun_new = zeros(1, N);   % fitness values

MOP_Max = 1;
MOP_Min = 0.2;
C_Iter = 1;
Alpha = 5;
Mu = 0.499;

% Evaluate initial population
for i = 1:N
    Ffun(i) = F_obj(X(i,:));
    if Ffun(i) < Best_FF
        Best_FF = Ffun(i);
        Best_P = X(i,:);
    end
end

% Main loop
while C_Iter <= M_Iter
    
    MOP = 1 - ((C_Iter)^(1/Alpha) / M_Iter^(1/Alpha));   % Probability Ratio
    MOA = MOP_Min + C_Iter * ((MOP_Max - MOP_Min)/M_Iter); % Accelerated function
    
    for i = 1:N
        for j = 1:Dim
            r1 = rand();
            if length(LB) == 1
                if r1 < MOA
                    r2 = rand();
                    if r2 > 0.5
                        Xnew(i,j) = Best_P(j)/(MOP+eps)*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j) = Best_P(j)*MOP*((UB-LB)*Mu+LB);
                    end
                else
                    r3 = rand();
                    if r3 > 0.5
                        Xnew(i,j) = Best_P(j) - MOP*((UB-LB)*Mu+LB);
                    else
                        Xnew(i,j) = Best_P(j) + MOP*((UB-LB)*Mu+LB);
                    end
                end
            else
                if r1 < MOA
                    r2 = rand();
                    if r2 > 0.5
                        Xnew(i,j) = Best_P(j)/(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j) = Best_P(j)*MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                else
                    r3 = rand();
                    if r3 > 0.5
                        Xnew(i,j) = Best_P(j) - MOP*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j) = Best_P(j) + MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                end
            end
        end
        
        % Bound check
        Flag_UB = Xnew(i,:) > UB;
        Flag_LB = Xnew(i,:) < LB;
        Xnew(i,:) = Xnew(i,:).*(~(Flag_UB+Flag_LB)) + UB.*Flag_UB + LB.*Flag_LB;
        
        % Evaluate fitness
        Ffun_new(i) = F_obj(Xnew(i,:));
        
        % Accept if better
        if Ffun_new(i) < Ffun(i)
            X(i,:) = Xnew(i,:);
            Ffun(i) = Ffun_new(i);
        end
        
        % Update best
        if Ffun(i) < Best_FF
            Best_FF = Ffun(i);
            Best_P = X(i,:);
        end
    end
    
    % Save history
    Conv_curve(C_Iter) = Best_FF;
    Trajectories(:,C_Iter) = Ffun';
    fitness_history(:,C_Iter) = Ffun';
    position_history(:,:,C_Iter) = X;
    
    % Display every 50 iterations
    if mod(C_Iter,50) == 0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF)]);
    end
    
    C_Iter = C_Iter + 1;
end

end
