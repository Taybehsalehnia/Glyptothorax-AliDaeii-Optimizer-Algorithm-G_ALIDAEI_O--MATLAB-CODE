%==================================================================
% Aquila Optimizer (AO) - Function Version for MAIN
%==================================================================
function [Best_FF, Best_P, cg_curve, Trajectories, fitness_history, position_history] = AO(N, T, LB, UB, Dim, F_obj)

% Best solution initialization
Best_P = zeros(1, Dim);
Best_FF = inf;

% Initialize population
X = initialization(N, Dim, UB, LB);
Xnew = X;

Ffun = zeros(1, N);
Ffun_new = zeros(1, N);

% History tracking
Trajectories = zeros(N, T);
fitness_history = zeros(N, T);
position_history = zeros(N, Dim, T);  % ????? ??
cg_curve = zeros(1, T);               % ????? ???????

t = 1;

alpha = 0.1;
delta = 0.1;

% Evaluate initial population
for i = 1:N
    % Bound check
    F_UB = X(i,:) > UB;
    F_LB = X(i,:) < LB;
    X(i,:) = X(i,:).*(~(F_UB + F_LB)) + UB.*F_UB + LB.*F_LB;
    
    % Objective evaluation
    Ffun(i) = F_obj(X(i,:));
    
    % Update best
    if Ffun(i) < Best_FF
        Best_FF = Ffun(i);
        Best_P = X(i,:);
    end
end

% Main loop
while t <= T
    
    G2 = 2*rand() - 1;
    G1 = 2*(1 - t/T);
    
    to = 1:Dim;
    u = 0.0265;
    r0 = 10;
    r = r0 + u*to;
    omega = 0.005;
    phi0 = 3*pi/2;
    phi = -omega*to + phi0;
    x = r .* sin(phi);
    y = r .* cos(phi);
    
    QF = t^((2*rand()-1)/(1-T)^2);
    
    for i = 1:N
        if t <= (2/3)*T
            if rand < 0.5
                Xnew(i,:) = Best_P*(1 - t/T) + (mean(X(i,:)) - Best_P)*rand();
            else
                Xnew(i,:) = Best_P .* Levy(Dim) + X(floor(N*rand()+1),:) + (y-x)*rand();
            end
        else
            if rand < 0.5
                Xnew(i,:) = (Best_P - mean(X)) * alpha - rand + ((UB-LB).*rand(1,Dim)+LB) * delta;
            else
                Xnew(i,:) = QF*Best_P - (G2*X(i,:)*rand) - G1.*Levy(Dim) + rand*G2;
            end
        end
        
        % Bound check
        F_UB = Xnew(i,:) > UB;
        F_LB = Xnew(i,:) < LB;
        Xnew(i,:) = Xnew(i,:).*(~(F_UB + F_LB)) + UB.*F_UB + LB.*F_LB;
        
        % Evaluate
        Ffun_new(i) = F_obj(Xnew(i,:));
        
        % Accept if better
        if Ffun_new(i) < Ffun(i)
            X(i,:) = Xnew(i,:);
            Ffun(i) = Ffun_new(i);
        end
        
        % Update best
        if Ffun(i) < Best_FF
            Best_FF = Ffun(i);
            Best_P = X(i,:);
        end
    end
    
    % Save history
    Trajectories(:,t) = Ffun';
    fitness_history(:,t) = Ffun';
    position_history(:,:,t) = X;  % ????? ????? ??
    cg_curve(t) = Best_FF;
    
    t = t + 1;
end

end

%==================================================================
% Levy flight function
%==================================================================
function step = Levy(d)
beta = 1.5;
sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u = randn(1,d)*sigma;
v = randn(1,d);
step = u ./ abs(v).^(1/beta);
end
