function [Target_score, Target_pos, cg_curve, Trajectories, fitness_history, position_history] = EO(Particles_no, Max_iter, lb, ub, dim, fobj)

% ????????????
C = initialization(Particles_no, dim, ub, lb);
fitness = zeros(Particles_no,1);
Convergence_curve = zeros(Max_iter,1);

Trajectories = zeros(Max_iter, Particles_no, dim);
fitness_history = zeros(Max_iter, Particles_no);
position_history = zeros(Max_iter, Particles_no, dim);

% Equilibrium candidates
Ceq1 = zeros(1,dim); Ceq1_fit = inf;
Ceq2 = zeros(1,dim); Ceq2_fit = inf;
Ceq3 = zeros(1,dim); Ceq3_fit = inf;
Ceq4 = zeros(1,dim); Ceq4_fit = inf;

Iter = 0; V = 1;
a1 = 2; a2 = 1; GP = 0.5;

fit_old = zeros(Particles_no,1);
C_old = zeros(Particles_no,dim);

while Iter < Max_iter
    for i = 1:Particles_no
        % ????? ?????
        C(i,:) = max(min(C(i,:), ub), lb);
        fitness(i) = fobj(C(i,:));

        % ????????? equilibrium candidates
        if fitness(i) < Ceq1_fit
            Ceq1_fit = fitness(i); Ceq1 = C(i,:);
        elseif fitness(i) > Ceq1_fit && fitness(i) < Ceq2_fit
            Ceq2_fit = C(i,:);
            Ceq2_fit = fitness(i);
        elseif fitness(i) > Ceq1_fit && fitness(i) > Ceq2_fit && fitness(i) < Ceq3_fit
            Ceq3_fit = C(i,:);
            Ceq3_fit = fitness(i);
        elseif fitness(i) > Ceq1_fit && fitness(i) > Ceq2_fit && fitness(i) > Ceq3_fit && fitness(i) < Ceq4_fit
            Ceq4_fit = C(i,:);
            Ceq4_fit = fitness(i);
        end
    end

    % Memory saving
    if Iter == 0
        fit_old = fitness; C_old = C;
    else
        for i = 1:Particles_no
            if fit_old(i) < fitness(i)
                fitness(i) = fit_old(i);
                C(i,:) = C_old(i,:);
            end
        end
        C_old = C; fit_old = fitness;
    end

    % Equilibrium pool
    Ceq_ave = (Ceq1 + Ceq2 + Ceq3 + Ceq4)/4;
    C_pool = [Ceq1; Ceq2; Ceq3; Ceq4; Ceq_ave];

    % ???? ??????
    t = (1 - Iter/Max_iter)^(a2*Iter/Max_iter);

    % ????????? ????
    for i = 1:Particles_no
        lambda = rand(1,dim);
        r = rand(1,dim);
        Ceq = C_pool(randi(size(C_pool,1)),:);

        F = a1*sign(r-0.5).*(exp(-lambda.*t)-1);

        r1 = rand(); r2 = rand();
        GCP = 0.5*r1*ones(1,dim).*(r2>=GP);
        G0 = GCP.*(Ceq - lambda.*C(i,:));
        G = G0.*F;
        C(i,:) = Ceq + (C(i,:) - Ceq).*F + (G./lambda*V).*(1-F);

        % ????? ?????
        C(i,:) = max(min(C(i,:), ub), lb);
    end

    Iter = Iter + 1;

    % ????? ???????
    Convergence_curve(Iter) = Ceq1_fit;
    Trajectories(Iter,:,:) = C;
    fitness_history(Iter,:) = fitness;
    position_history(Iter,:,:) = C;
end

% ????????
Target_score = Ceq1_fit;
Target_pos = Ceq1;
cg_curve = Convergence_curve;

end
