
%===========================================
% G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm
% Programmer : Taybeh Salehnia
% Email      : salehnia.taybeh@gmail.com
%===========================================
clc; 
clear all; 
close all;
%===========================================
disp('======================================');
disp('Programmer : Taybeh Salehnia');
disp('Email      : salehnia.taybeh@gmail.com');
disp('======================================');
%===========================================
disp('G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm');
disp('MFO       -- Moth Flame Optimization');
disp('AO        -- Aquila Optimizer');
disp('WOA       -- Whale Optimization Algorithm');
disp('AOA       -- Arithmetic Optimization Algorithm');
disp('Firefly   -- Firefly Algorithm');
disp('GOA       -- Grasshopper Optimization Algorithm');
disp('HHO       -- Harris Hawks Optimization');
disp('AVOA      -- African Vulture Optimization Algorithm');
disp('PSO       -- Particle Swarm Optimization');
disp('GWO       -- Grey Wolf Optimizer');
disp('SSA       -- Salp Swarm Algorithm');
disp('HOA       -- Harris Optimization Algorithm');
disp('EO        -- Equilibrium Optimizer');
disp('======================================');
%==========================================================================
%===========================================
% Programmer : Taybeh Salehnia
% Email      : salehnia.taybeh@gmail.com
%===========================================
%---------------------------------------------------------------------------
SearchAgents_no=100; % Number of search agents
Function_name='F1'; % Name of the test function that can be from F1 to F23 
Max_iteration=100; % Maximum number of iterations
%---------------------------------------------------------------------------
% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);

%%=========================================================================  
%---------------------- G_AliDaei_O ------------------------------------------
tic
[Target_score_GAliDaeiO,Target_pos_GAliDaeiO,cg_curve_GAliDaeiO, Trajectories_GAliDaeiO,fitness_history_GAliDaeiO, position_history_GAliDaeiO]=G_AliDaei_O(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_GAliDaeiO=toc;
figure('Name','G_AliDaei_O','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_GAliDaeiO,1)
    for k2 = 1: size(position_history_GAliDaeiO,2)
        plot(position_history_GAliDaeiO(k1,k2,1),position_history_GAliDaeiO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_GAliDaeiO(1),Target_pos_GAliDaeiO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_GAliDaeiO(1,:)); title('Trajectory of 1st G_AliDaei_O'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_GAliDaeiO)); title('Average fitness of all G_AliDaei_O'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_GAliDaeiO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['G_AliDaei_O best solution: ', num2str(Target_pos_GAliDaeiO)]);
display(['G_AliDaei_O best score: ', num2str(Target_score_GAliDaeiO)]);
%%=========================================================================
%---------------------- MFO -----------------------------------------------
tic
[Target_score_MFO,Target_pos_MFO,cg_curve_MFO, Trajectories_MFO,fitness_history_MFO, position_history_MFO]=MFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_MFO=toc;
figure('Name','MFO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_MFO,1)
    for k2 = 1: size(position_history_MFO,2)
        plot(position_history_MFO(k1,k2,1),position_history_MFO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_MFO(1),Target_pos_MFO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_MFO(1,:)); title('Trajectory of 1st MFO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_MFO)); title('Average fitness of all MFO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_MFO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['MFO best solution: ', num2str(Target_pos_MFO)]);
display(['MFO best score: ', num2str(Target_score_MFO)]);
%%=========================================================================
%%=========================================================================  
%---------------------- AO -----------------------------------------------
tic
[Target_score_AO,Target_pos_AO,cg_curve_AO, Trajectories_AO,fitness_history_AO, position_history_AO]=AO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_AO=toc;
figure('Name','AO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_AO,1)
    for k2 = 1: size(position_history_AO,2)
        plot(position_history_AO(k1,k2,1),position_history_AO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_AO(1),Target_pos_AO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_AO(1,:)); title('Trajectory of 1st AO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_AO)); title('Average fitness of all AO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_AO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['AO best solution: ', num2str(Target_pos_AO)]);
display(['AO best score: ', num2str(Target_score_AO)]);
%%=========================================================================
%---------------------- WOA -----------------------------------------------
tic
[Target_score_WOA,Target_pos_WOA,cg_curve_WOA, Trajectories_WOA,fitness_history_WOA, position_history_WOA]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_WOA=toc;
figure('Name','WOA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_WOA,1)
    for k2 = 1: size(position_history_WOA,2)
        plot(position_history_WOA(k1,k2,1),position_history_WOA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_WOA(1),Target_pos_WOA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_WOA(1,:)); title('Trajectory of 1st WOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_WOA)); title('Average fitness of all WOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_WOA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['WOA best solution: ', num2str(Target_pos_WOA)]);
display(['WOA best score: ', num2str(Target_score_WOA)]);
%%=========================================================================

%%=========================================================================  
%---------------------- AOA -----------------------------------------------
tic
[Target_score_AOA,Target_pos_AOA,cg_curve_AOA, Trajectories_AOA,fitness_history_AOA, position_history_AOA]=AOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_AOA=toc;
figure('Name','AOA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_AOA,1)
    for k2 = 1: size(position_history_AOA,2)
        plot(position_history_AOA(k1,k2,1),position_history_AOA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_AOA(1),Target_pos_AOA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_AOA(1,:)); title('Trajectory of 1st AOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_AOA)); title('Average fitness of all AOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_AOA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['AOA best solution: ', num2str(Target_pos_AOA)]);
display(['AOA best score: ', num2str(Target_score_AOA)]);
%%=========================================================================
%%=========================================================================  
%---------------------- Firefly -------------------------------------------
tic
[Target_score_Firefly,Target_pos_Firefly,cg_curve_Firefly, Trajectories_Firefly,fitness_history_Firefly, position_history_Firefly]=Firefly(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_Firefly=toc;
figure('Name','Firefly','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_Firefly,1)
    for k2 = 1: size(position_history_Firefly,2)
        plot(position_history_Firefly(k1,k2,1),position_history_Firefly(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_Firefly(1),Target_pos_Firefly(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_Firefly(1,:)); title('Trajectory of 1st Firefly'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_Firefly)); title('Average fitness of all Firefly'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_Firefly,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['Firefly best solution: ', num2str(Target_pos_Firefly)]);
display(['Firefly best score: ', num2str(Target_score_Firefly)]);
%%=========================================================================

%%=========================================================================  
%---------------------- GOA -----------------------------------------------
tic
[Target_score_GOA,Target_pos_GOA,cg_curve_GOA, Trajectories_GOA,fitness_history_GOA, position_history_GOA]=GOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_GOA=toc;
figure('Name','GOA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_GOA,1)
    for k2 = 1: size(position_history_GOA,2)
        plot(position_history_GOA(k1,k2,1),position_history_GOA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_GOA(1),Target_pos_GOA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_GOA(1,:)); title('Trajectory of 1st GOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_GOA)); title('Average fitness of all GOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_GOA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['GOA best solution: ', num2str(Target_pos_GOA)]);
display(['GOA best score: ', num2str(Target_score_GOA)]); 
%%========================================================================= 
%---------------------- HHO -----------------------------------------------
tic
[Target_score_HHO,Target_pos_HHO,cg_curve_HHO, Trajectories_HHO,fitness_history_HHO, position_history_HHO]=HHO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_HHO=toc;
figure('Name','HHO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_HHO,1)
    for k2 = 1: size(position_history_HHO,2)
        plot(position_history_HHO(k1,k2,1),position_history_HHO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_HHO(1),Target_pos_HHO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_HHO(1,:)); title('Trajectory of 1st HHO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_HHO)); title('Average fitness of all HHO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_HHO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['HHO best solution: ', num2str(Target_pos_HHO)]);
display(['HHO best score: ', num2str(Target_score_HHO)]);
%%========================================================================= 
%---------------------- AVOA ----------------------------------------------
tic
[Target_score_AVOA,Target_pos_AVOA,cg_curve_AVOA, Trajectories_AVOA,fitness_history_AVOA, position_history_AVOA]=AVOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_AVOA=toc;
figure('Name','AVOA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_AVOA,1)
    for k2 = 1: size(position_history_AVOA,2)
        plot(position_history_AVOA(k1,k2,1),position_history_AVOA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_AVOA(1),Target_pos_AVOA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_AVOA(1,:)); title('Trajectory of 1st AVOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_AVOA)); title('Average fitness of all AVOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_AVOA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['AVOA best solution: ', num2str(Target_pos_AVOA)]);
display(['AVOA best score: ', num2str(Target_score_AVOA)]);
%%=========================================================================
%---------------------- PSO -----------------------------------------------
tic
[Target_score_PSO,Target_pos_PSO,cg_curve_PSO, Trajectories_PSO,fitness_history_PSO, position_history_PSO]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_PSO=toc;
figure('Name','PSO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_PSO,1)
    for k2 = 1: size(position_history_PSO,2)
        plot(position_history_PSO(k1,k2,1),position_history_PSO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_PSO(1),Target_pos_PSO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_PSO(1,:)); title('Trajectory of 1st PSO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_PSO)); title('Average fitness of all PSO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_PSO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['PSO best solution: ', num2str(Target_pos_PSO)]);
display(['PSO best score: ', num2str(Target_score_PSO)]);
%%=========================================================================
%---------------------- GWO -----------------------------------------------
tic
[Target_score_GWO,Target_pos_GWO,cg_curve_GWO, Trajectories_GWO,fitness_history_GWO, position_history_GWO]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_GWO=toc;
figure('Name','GWO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_GWO,1)
    for k2 = 1: size(position_history_GWO,2)
        plot(position_history_GWO(k1,k2,1),position_history_GWO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_GWO(1),Target_pos_GWO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_GWO(1,:)); title('Trajectory of 1st GWO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_GWO)); title('Average fitness of all GWO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_GWO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['GWO best solution: ', num2str(Target_pos_GWO)]);
display(['GWO best score: ', num2str(Target_score_GWO)]);
%%=========================================================================
%---------------------- SSA -----------------------------------------------
tic
[Target_score_SSA,Target_pos_SSA,cg_curve_SSA, Trajectories_SSA,fitness_history_SSA, position_history_SSA]=SSA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_SSA=toc;
figure('Name','SSA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_SSA,1)
    for k2 = 1: size(position_history_SSA,2)
        plot(position_history_SSA(k1,k2,1),position_history_SSA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_SSA(1),Target_pos_SSA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_SSA(1,:)); title('Trajectory of 1st SSA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_SSA)); title('Average fitness of all SSA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_SSA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['SSA best solution: ', num2str(Target_pos_SSA)]);
display(['SSA best score: ', num2str(Target_score_SSA)]);
%%========================================================================= 
%---------------------- HOA -----------------------------------------------
tic
[Target_score_HOA,Target_pos_HOA,cg_curve_HOA, Trajectories_HOA,fitness_history_HOA, position_history_HOA]=HOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_HOA=toc;
figure('Name','HOA','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_HOA,1)
    for k2 = 1: size(position_history_HOA,2)
        plot(position_history_HOA(k1,k2,1),position_history_HOA(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_HOA(1),Target_pos_HOA(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_HOA(1,:)); title('Trajectory of 1st HOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_HOA)); title('Average fitness of all HOA'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_HOA,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['HOA best solution: ', num2str(Target_pos_HOA)]);
display(['HOA best score: ', num2str(Target_score_HOA)]);
%%=========================================================================
%---------------------- EO -----------------------------------------------
tic
[Target_score_EO,Target_pos_EO,cg_curve_EO, Trajectories_EO,fitness_history_EO, position_history_EO]=EO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
time_EO=toc;
figure('Name','EO','Position',[100 100 1400 300])
subplot(1,5,1); func_plot(Function_name); title('Parameter space'); xlabel('x_1'); ylabel('x_2'); zlabel([Function_name,'( x_1 , x_2 )']); box on; axis tight
subplot(1,5,2); hold on
for k1 = 1: size(position_history_EO,1)
    for k2 = 1: size(position_history_EO,2)
        plot(position_history_EO(k1,k2,1),position_history_EO(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
    end
end
plot(Target_pos_EO(1),Target_pos_EO(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
title('Search history (x1 and x2 only)'); xlabel('x1'); ylabel('x2'); box on; axis tight
subplot(1,5,3); plot(Trajectories_EO(1,:)); title('Trajectory of 1st EO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,4); plot(mean(fitness_history_EO)); title('Average fitness of all EO'); xlabel('Iteration#'); box on; axis tight
subplot(1,5,5); semilogy(cg_curve_EO,'Color','r'); title('Convergence curve'); xlabel('Iteration#'); ylabel('Best score obtained so far'); box on; axis tight
display(['EO best solution: ', num2str(Target_pos_EO)]);
display(['EO best score: ', num2str(Target_score_EO)]);
%%=========================================================================
%===========================================
% G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm
% Programmer : Taybeh Salehnia
% Email      : salehnia.taybeh@gmail.com
%===========================================
disp('======================================');
disp('Programmer : Taybeh Salehnia');
disp('Email      : salehnia.taybeh@gmail.com');
disp('======================================');
%===========================================
disp('G_AliDaei_O -- Glyptothorax AliDaeii Optimizer Algorithm');


